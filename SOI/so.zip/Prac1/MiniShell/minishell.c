#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>


#define MAXLEN 1024
#define MAXARG 10

int manageExit(char *buff){
    if(strcmp("quit\n\0",buff) == 0) return 0;
    if(strcmp("q\n\0",buff) == 0) return 0;
    if(strcmp("exit\n\0",buff) == 0) return 0;
    return 1;
}

void executeCommand(char* command, char** argv){
    pid_t pid = fork();
    int status;
    if(pid == 0){
        //printf("Argv[1]: %s\n",argv[1]);
        //printf("PID ACTUAL: %d\n",getpid());
        execvp(command, (char *const*)argv);
        exit(0);
    }else{
        // printf("PID ACTUAL (padre): %d\n",getpid());
        wait(&status);
        return;
    }
}

void manageCommand(char *buff){
    buff[strcspn(buff, "\n")] = '\0';
    char* token = strtok(buff, " \n");
    char command[MAXLEN];
    char* argv[MAXARG + 1];
    int i = 0;
    strcpy(command, token); 
    argv[0] = token;
    i++; 
    // printf("[PRIVATE] Comando ingresado: %s\n", token);
    while(token != NULL){
        // printf("[PRIVATE] Leyendo argumentos...\n");
        if(i > MAXARG){
            perror("[ERR] ERROR: MAS ARGUMENTOS QUE EL MAXIMO PERMITIDO. ");
            exit(EXIT_FAILURE);
        }
        token = strtok(NULL, " ");
        if(token != NULL){
            argv[i] = strdup(token);
            // printf("[PRIVATE] Argumento #%d ingresado: %s\n", i, argv[i]);
            i++;
        }
    }
    argv[i] = NULL;
    // Termine de leer argumenos y comando, ejecutar.
    executeCommand(command, argv);

    for (int j = 1; j < i; j++) {  // No liberar argv[0] porque es el comando
        free(argv[j]);
    }
    return;
}

void start(){

    int bandera = 1;
    char buff[MAXLEN];
    printf("¡Bienvenido a la MiniShell! \n");

    while(bandera){
        printf("> ");
        fgets(buff, sizeof(buff), stdin);
        bandera = manageExit(buff);
        if(bandera){
            // La palabra no fue de salida, procesar.
            manageCommand(buff);
        }

        
    }

    printf("Vuelva pronto!\n");
    return;
}

int main(){
    start();
    return 0;
}